<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('passport_districts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('provience_id')->constrained('passport_proviences')->onDelete('cascade');
            $table->string('districtName');
            $table->string('slug')->unique();
            $table->boolean('publishStatus')->default(false);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('passport_districts');
    }
};
