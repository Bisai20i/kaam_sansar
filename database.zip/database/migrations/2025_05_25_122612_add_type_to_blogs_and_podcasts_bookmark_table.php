<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('blogs_and_podcasts_bookmarks', function (Blueprint $table) {
            $table->enum('type', ['article', 'podcast'])->default('article');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('blogs_and_podcasts_bookmarks', function (Blueprint $table) {
            $table->dropColumn('type');
        });
    }
};
