  <style>
      .loader {
          display: flex;
          flex-direction: column;
          gap: 15px;
      }

      .loader div {
          width: 40px;
          height: 40px;
          border: 5px solid #007bff;
          border-radius: 50%;
          border-top-color: transparent;
          animation: spin 1s linear infinite;
      }

      .loader div:nth-child(2) {
          animation-delay: 0.2s;
      }

      .loader div:nth-child(3) {
          animation-delay: 0.4s;
      }

      .loader div:nth-child(4) {
          animation-delay: 0.6s;
      }

      @keyframes spin {
          0% {
              transform: rotate(0deg);
          }

          100% {
              transform: rotate(360deg);
          }
      }
  </style>

  <!DOCTYPE html>
  <html lang="en">

  <head>
      <meta charset="UTF-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <title>Loader Animation</title>
      <style>
          body {
              display: flex;
              justify-content: center;
              align-items: center;
              height: 100vh;
              background-color: #333;
          }

          .loader {
              display: flex;
              flex-direction: column;
              gap: 15px;
          }

          .loader div {
              width: 40px;
              height: 40px;
              border: 5px solid #007bff;
              border-radius: 50%;
              border-top-color: transparent;
              animation: spin 1s linear infinite;
          }

          .loader div:nth-child(2) {
              animation-delay: 0.2s;
          }

          .loader div:nth-child(3) {
              animation-delay: 0.4s;
          }

          .loader div:nth-child(4) {
              animation-delay: 0.6s;
          }

          @keyframes spin {
              0% {
                  transform: rotate(0deg);
              }

              100% {
                  transform: rotate(360deg);
              }
          }
      </style>
  </head>

  <body>
      <div class="loader">
          <div></div>

      </div>
  </body>

  </html>
