<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Question extends Model
{
    use HasFactory;
    protected $guarded =[]; 
  

    public function answers()
    {
        return $this->hasMany(Answer::class);
    }


    public function admin()
    {
        return $this->belongsTo(Admin::class);
    }
}
